package com.example.harekrishna.higherorlower;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import java.util.Random;

public class MainActivity extends AppCompatActivity {
    int num;
    public void generaterandom(){
        Random rand=new Random();
        num=rand.nextInt(21) +1;

    }
    public void guess(View view) {
        EditText noeditText=(EditText)findViewById(R.id.noeditText);
        Log.i("Guessed number  ",noeditText.getText().toString());
       String noedittext=noeditText.toString();
       int text=Integer.parseInt(noeditText.getText().toString());

     Log.i("number ",Integer.toString(num));

      if(text>num) {
            Toast.makeText(this, " Try Lower", Toast.LENGTH_SHORT).show();
        }
        else if(text<num) {
            Toast.makeText(this, "Try Higher", Toast.LENGTH_SHORT).show();
        }
        else
            Toast.makeText(this, "Corect!,Play again", Toast.LENGTH_SHORT).show();
      generaterandom();
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


    }
}
