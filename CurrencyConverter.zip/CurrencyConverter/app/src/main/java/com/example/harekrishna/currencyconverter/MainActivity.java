package com.example.harekrishna.currencyconverter;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    public void convertfunc(View view) {
        Log.i("Info","Working!");
        EditText inputeditText=(EditText)findViewById(R.id.inputeditText);
        Log.i("Amount ",inputeditText.getText().toString());
        String amountindollars=inputeditText.getText().toString();
        Log.i(" amount",amountindollars);
        Double amountindollarsdouble=Double.parseDouble(amountindollars);
        Double amountinrupee=amountindollarsdouble*60;
        String amountinrupeestring=String.format("%.2f",amountinrupee);
        Toast.makeText(this, amountindollars+ " dollars is "+ amountinrupeestring +" rupees", Toast.LENGTH_SHORT).show();

    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}
