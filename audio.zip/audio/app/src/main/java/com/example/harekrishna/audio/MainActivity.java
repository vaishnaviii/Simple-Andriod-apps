package com.example.harekrishna.audio;

import android.media.AudioManager;
import android.media.MediaPlayer;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.SeekBar;

import java.util.Timer;
import java.util.TimerTask;

public class MainActivity extends AppCompatActivity {
    MediaPlayer mediaPlayer;
    AudioManager audiomanager;

    public void play(View view) {
        Log.i("info", " worked");
        mediaPlayer.start();

    }

    public void pause(View view) {
        Log.i("info", " worked!");
        mediaPlayer.pause();

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        audiomanager=(AudioManager)getSystemService(AUDIO_SERVICE);

        int maxvol=audiomanager.getStreamVolume(AudioManager.STREAM_MUSIC);
        int curvol=audiomanager.getStreamVolume(AudioManager.STREAM_MUSIC);


        mediaPlayer = MediaPlayer.create(this, R.raw.marbles);
        SeekBar seekBar = (SeekBar) findViewById(R.id.seekBar);
        seekBar.setMax(maxvol);
        seekBar.setProgress(curvol);
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                Log.i("Info", Integer.toString(i));
                audiomanager.setStreamVolume(AudioManager.STREAM_MUSIC,i,0 );



            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }


        });

        final SeekBar seekbar2=(SeekBar)findViewById(R.id.seekbar2);
        seekbar2.setMax(mediaPlayer.getDuration());
        seekbar2.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                Log.i("info",Integer.toString(i));
                mediaPlayer.seekTo(i);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });
new Timer().scheduleAtFixedRate(new TimerTask() {
    @Override
    public void run() {
        seekbar2.setProgress(mediaPlayer.getCurrentPosition());
    }
   },  0,300);
    }
}
